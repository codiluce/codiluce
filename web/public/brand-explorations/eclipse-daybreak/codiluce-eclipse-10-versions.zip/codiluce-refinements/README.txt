Codiluce Eclipse: ten typography and proportion variations.
Each numbered folder contains transparent SVGs and dark/light presentation SVGs and PNGs.
Tagline: Bring your code to light.
